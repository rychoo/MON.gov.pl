Important notice: Official NASA WorldWind development is suspended, beginning May 3rd, 2019. The maintainers will not attend pull requests in the foreseeable future. You are welcome to submit this pull request anyway for the benefit of the community. More information in the following link:
 
https://worldwind.arc.nasa.gov/news/2019-03-21-suspension-faq/
